package poswarungkopi;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** In-memory catalog, cart, and transaction history. */
public final class CashierService {
    private final Map<String, Product> products = new LinkedHashMap<>();
    private final Map<String, CartItem> cart = new LinkedHashMap<>();
    private final List<Transaction> history = new ArrayList<>();
    private int transactionNumber = 1;

    public CashierService() {
        addProduct(new Coffee("K01", "Espresso", 18000, "single origin"));
        addProduct(new Coffee("K02", "Americano", 22000, "house blend"));
        addProduct(new Coffee("K03", "Cafe Latte", 28000, "house blend dengan susu"));
        addProduct(new Coffee("K04", "Kopi Susu Senja", 25000, "house blend dengan gula aren"));
        addProduct(new NonCoffee("N01", "Matcha Latte", 28000, "Teh matcha dengan susu"));
        addProduct(new NonCoffee("N02", "Cokelat", 24000, "Minuman cokelat hangat atau dingin"));
        addProduct(new NonCoffee("N03", "Teh Lemon", 18000, "Teh dengan lemon segar"));
    }

    public void addProduct(Product product) {
        if (products.putIfAbsent(product.getCode(), product) != null)
            throw new IllegalArgumentException("Kode produk sudah digunakan.");
    }

    public List<Product> getProducts() { return List.copyOf(products.values()); }
    public List<CartItem> getCartItems() {
        return cart.values().stream().map(item -> new CartItem(item.getProduct(), item.getQuantity())).toList();
    }
    public List<Transaction> getHistory() { return Collections.unmodifiableList(history); }
    public Product findProduct(String code) { return products.get(code.toUpperCase()); }

    public void addToCart(String code, int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("Jumlah harus lebih besar dari nol.");
        Product product = findProduct(code.trim());
        if (product == null) throw new IllegalArgumentException("Kode produk tidak ditemukan.");
        CartItem current = cart.get(product.getCode());
        if (current == null) cart.put(product.getCode(), new CartItem(product, quantity));
        else current.addQuantity(quantity);
    }

    public void removeFromCart(String code) {
        if (cart.remove(code.trim().toUpperCase()) == null)
            throw new IllegalArgumentException("Produk tersebut tidak ada di keranjang.");
    }

    public long getCartTotal() {
        long total = 0;
        for (CartItem item : cart.values()) total = Math.addExact(total, item.getSubtotal());
        return total;
    }

    public Transaction checkout(long payment) {
        if (cart.isEmpty()) throw new IllegalStateException("Keranjang masih kosong.");
        long total = getCartTotal();
        if (payment < total) throw new IllegalArgumentException("Pembayaran kurang. Kekurangan: " + Product.formatRupiah(total - payment));
        String id = "TRX-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMdd-HHmmss"))
                + "-" + String.format("%03d", transactionNumber++);
        Transaction transaction = new Transaction(id, LocalDateTime.now(), getCartItems(), total, payment);
        history.add(transaction);
        cart.clear();
        return transaction;
    }
}
