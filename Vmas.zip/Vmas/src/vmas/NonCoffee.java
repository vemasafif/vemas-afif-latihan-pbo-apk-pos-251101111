package poswarungkopi;

public final class NonCoffee extends Product {
    private final String description;

    public NonCoffee(String code, String name, long price, String description) {
        super(code, name, price);
        this.description = description;
    }

    @Override public String getCategory() { return "Non-kopi"; }
    @Override public String getDescription() { return description; }
}
