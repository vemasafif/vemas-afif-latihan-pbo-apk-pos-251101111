package poswarungkopi;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.Objects;

/** Shared data and behavior for every product sold by the shop. */
public abstract class Product {
    private final String code;
    private final String name;
    private final long price;

    protected Product(String code, String name, long price) {
        if (code == null || code.isBlank()) throw new IllegalArgumentException("Kode produk wajib diisi.");
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Nama produk wajib diisi.");
        if (price < 0) throw new IllegalArgumentException("Harga tidak boleh negatif.");
        this.code = code.toUpperCase(Locale.ROOT);
        this.name = name;
        this.price = price;
    }

    public String getCode() { return code; }
    public String getName() { return name; }
    public long getPrice() { return price; }
    public abstract String getCategory();
    public abstract String getDescription();

    public static String formatRupiah(long amount) {
        return NumberFormat.getCurrencyInstance(Locale.forLanguageTag("id-ID")).format(amount)
                .replace(",00", "");
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof Product product && code.equals(product.code);
    }

    @Override
    public int hashCode() { return Objects.hash(code); }
}
