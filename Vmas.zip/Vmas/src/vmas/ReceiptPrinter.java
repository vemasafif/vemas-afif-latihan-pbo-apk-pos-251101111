package poswarungkopi;

import java.time.format.DateTimeFormatter;

public final class ReceiptPrinter {
    private ReceiptPrinter() { }

    public static void print(Transaction transaction) {
        System.out.println("\n========================================");
        System.out.println("          WARUNG KOPI SENJA");
        System.out.println("========================================");
        System.out.println("No.   : " + transaction.getId());
        System.out.println("Waktu : " + transaction.getCreatedAt().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")));
        System.out.println("----------------------------------------");
        for (CartItem item : transaction.getItems()) {
            System.out.printf("%-23s x%-3d %12s%n", item.getProduct().getName(), item.getQuantity(),
                    Product.formatRupiah(item.getSubtotal()));
        }
        System.out.println("----------------------------------------");
        System.out.printf("%-24s %14s%n", "Total", Product.formatRupiah(transaction.getTotal()));
        System.out.printf("%-24s %14s%n", "Tunai", Product.formatRupiah(transaction.getPayment()));
        System.out.printf("%-24s %14s%n", "Kembalian", Product.formatRupiah(transaction.getChange()));
        System.out.println("========================================");
        System.out.println("     Terima kasih, selamat menikmati!");
        System.out.println("========================================\n");
    }
}
