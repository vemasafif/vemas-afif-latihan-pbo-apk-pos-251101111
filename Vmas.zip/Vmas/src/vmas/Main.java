package poswarungkopi;

import java.util.Scanner;

/** Entry point and Indonesian command-line interaction. */
public final class Main {
    private final Scanner scanner = new Scanner(System.in);
    private final CashierService cashier = new CashierService();

    public static void main(String[] args) { new Main().run(); }

    private void run() {
        System.out.println("Selamat datang di POS Warung Kopi Senja!");
        boolean running = true;
        while (running) {
            System.out.println("\n--- MENU UTAMA ---");
            System.out.println("1. Lihat daftar produk\n2. Tambah produk ke keranjang\n3. Lihat keranjang\n4. Hapus produk dari keranjang");
            System.out.println("5. Checkout dan bayar\n6. Riwayat transaksi\n0. Keluar");
            switch (readInt("Pilih menu: ")) {
                case 1 -> showProducts();
                case 2 -> addItem();
                case 3 -> showCart();
                case 4 -> removeItem();
                case 5 -> checkout();
                case 6 -> showHistory();
                case 0 -> running = false;
                default -> System.out.println("Pilihan tidak tersedia.");
            }
        }
        System.out.println("Sampai jumpa di Warung Kopi Senja.");
    }

    private void showProducts() {
        System.out.println("\n--- DAFTAR PRODUK ---");
        System.out.printf("%-5s %-22s %-11s %-15s %s%n", "Kode", "Nama", "Kategori", "Harga", "Deskripsi");
        for (Product product : cashier.getProducts())
            System.out.printf("%-5s %-22s %-11s %-15s %s%n", product.getCode(), product.getName(),
                    product.getCategory(), Product.formatRupiah(product.getPrice()), product.getDescription());
    }

    private void addItem() {
        String code = readLine("Masukkan kode produk: ");
        int quantity = readInt("Jumlah: ");
        try {
            cashier.addToCart(code, quantity);
            System.out.println("Produk berhasil ditambahkan ke keranjang.");
        } catch (IllegalArgumentException | ArithmeticException error) { System.out.println("Gagal: " + error.getMessage()); }
    }

    private void showCart() {
        System.out.println("\n--- KERANJANG ---");
        if (cashier.getCartItems().isEmpty()) { System.out.println("Keranjang masih kosong."); return; }
        System.out.printf("%-5s %-22s %5s %15s %15s%n", "Kode", "Nama", "Qty", "Harga", "Subtotal");
        for (CartItem item : cashier.getCartItems())
            System.out.printf("%-5s %-22s %5d %15s %15s%n", item.getProduct().getCode(), item.getProduct().getName(),
                    item.getQuantity(), Product.formatRupiah(item.getProduct().getPrice()), Product.formatRupiah(item.getSubtotal()));
        System.out.println("Total: " + Product.formatRupiah(cashier.getCartTotal()));
    }

    private void removeItem() {
        showCart();
        if (cashier.getCartItems().isEmpty()) return;
        try {
            cashier.removeFromCart(readLine("Masukkan kode produk yang dihapus: "));
            System.out.println("Produk dihapus dari keranjang.");
        } catch (IllegalArgumentException error) { System.out.println("Gagal: " + error.getMessage()); }
    }

    private void checkout() {
        if (cashier.getCartItems().isEmpty()) { System.out.println("Checkout gagal: keranjang masih kosong."); return; }
        showCart();
        long payment = readLong("Jumlah pembayaran tunai (Rp): ");
        try { ReceiptPrinter.print(cashier.checkout(payment)); }
        catch (IllegalArgumentException | IllegalStateException | ArithmeticException error) {
            System.out.println("Checkout gagal: " + error.getMessage());
        }
    }

    private void showHistory() {
        System.out.println("\n--- RIWAYAT TRANSAKSI ---");
        if (cashier.getHistory().isEmpty()) { System.out.println("Belum ada transaksi."); return; }
        for (Transaction transaction : cashier.getHistory())
            System.out.printf("%s | %s | %d item | Total %s | Tunai %s | Kembali %s%n",
                    transaction.getId(), transaction.getCreatedAt().format(java.time.format.DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm")),
                    transaction.getItems().stream().mapToInt(CartItem::getQuantity).sum(), Product.formatRupiah(transaction.getTotal()),
                    Product.formatRupiah(transaction.getPayment()), Product.formatRupiah(transaction.getChange()));
    }

    private String readLine(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    private int readInt(String prompt) {
        while (true) {
            try { return Integer.parseInt(readLine(prompt)); }
            catch (NumberFormatException error) { System.out.println("Masukkan angka bulat yang valid."); }
        }
    }

    private long readLong(String prompt) {
        while (true) {
            try { return Long.parseLong(readLine(prompt).replace(".", "").replace(",", "")); }
            catch (NumberFormatException error) { System.out.println("Masukkan nominal angka yang valid, tanpa simbol Rp."); }
        }
    }
}
