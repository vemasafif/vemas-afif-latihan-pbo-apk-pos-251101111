package poswarungkopi;

import java.time.LocalDateTime;
import java.util.List;

public final class Transaction {
    private final String id;
    private final LocalDateTime createdAt;
    private final List<CartItem> items;
    private final long total;
    private final long payment;
    private final long change;

    public Transaction(String id, LocalDateTime createdAt, List<CartItem> items, long total, long payment) {
        if (payment < total) throw new IllegalArgumentException("Pembayaran kurang dari total transaksi.");
        this.id = id;
        this.createdAt = createdAt;
        this.items = items.stream().map(item -> new CartItem(item.getProduct(), item.getQuantity())).toList();
        this.total = total;
        this.payment = payment;
        this.change = payment - total;
    }

    public String getId() { return id; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public List<CartItem> getItems() { return items; }
    public long getTotal() { return total; }
    public long getPayment() { return payment; }
    public long getChange() { return change; }
}
