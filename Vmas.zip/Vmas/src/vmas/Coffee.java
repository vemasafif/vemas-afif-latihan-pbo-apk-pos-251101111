package poswarungkopi;

public final class Coffee extends Product {
    private final String roast;

    public Coffee(String code, String name, long price, String roast) {
        super(code, name, price);
        this.roast = roast;
    }

    @Override public String getCategory() { return "Kopi"; }
    @Override public String getDescription() { return "Kopi " + roast; }
}
