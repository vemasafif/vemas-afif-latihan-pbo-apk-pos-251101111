package poswarungkopi;

public final class CartItem {
    private final Product product;
    private int quantity;

    public CartItem(Product product, int quantity) {
        if (product == null) throw new IllegalArgumentException("Produk wajib diisi.");
        if (quantity <= 0) throw new IllegalArgumentException("Jumlah harus lebih besar dari nol.");
        this.product = product;
        this.quantity = quantity;
    }

    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }
    public long getSubtotal() { return Math.multiplyExact(product.getPrice(), quantity); }
    public void addQuantity(int amount) {
        if (amount <= 0) throw new IllegalArgumentException("Jumlah harus lebih besar dari nol.");
        quantity = Math.addExact(quantity, amount);
    }
}
