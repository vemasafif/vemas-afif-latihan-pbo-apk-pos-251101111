package poswarungkopi;

public class Kasir extends Pengguna {
    private String idKasir;

    public Kasir(String nama, String idKasir) {
        super(nama);
        this.idKasir = idKasir;
    }

    public String getIdKasir() {
        return idKasir;
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("Kasir: " + getNama() + " | ID: " + idKasir);
    }
}
