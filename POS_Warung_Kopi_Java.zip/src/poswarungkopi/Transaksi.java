package poswarungkopi;

import java.util.ArrayList;
import java.util.List;

public class Transaksi {
    private static final double BATAS_DISKON = 100000;
    private static final double PERSEN_DISKON = 0.10;

    private String nomorTransaksi;
    private Kasir kasir;
    private List<ItemPesanan> itemPesanan;

    public Transaksi(String nomorTransaksi, Kasir kasir) {
        this.nomorTransaksi = nomorTransaksi;
        this.kasir = kasir;
        this.itemPesanan = new ArrayList<>();
    }

    public void tambahItem(Menu menu, int jumlah) {
        if (jumlah <= 0) {
            throw new IllegalArgumentException("Jumlah harus lebih dari 0.");
        }
        itemPesanan.add(new ItemPesanan(menu, jumlah));
    }

    public double hitungSubtotal() {
        double subtotal = 0;
        for (ItemPesanan item : itemPesanan) {
            subtotal += item.getSubtotal();
        }
        return subtotal;
    }

    public double hitungDiskon() {
        return hitungSubtotal() >= BATAS_DISKON
                ? hitungSubtotal() * PERSEN_DISKON : 0;
    }

    public double hitungTotal() {
        return hitungSubtotal() - hitungDiskon();
    }

    public void cetakStruk(Pembayaran pembayaran, double uangDibayar, double kembalian) {
        System.out.println("\n================ STRUK WARUNG KOPI ================");
        System.out.println("No. Transaksi : " + nomorTransaksi);
        System.out.println("Kasir         : " + kasir.getNama());
        System.out.println("---------------------------------------------------");
        System.out.printf("%-22s %5s %14s%n", "Menu", "Qty", "Subtotal");
        for (ItemPesanan item : itemPesanan) {
            System.out.printf("%-22s %5d Rp%,12.0f%n",
                    item.getMenu().getNama(), item.getJumlah(), item.getSubtotal());
        }
        System.out.println("---------------------------------------------------");
        System.out.printf("%-28s Rp%,12.0f%n", "Subtotal:", hitungSubtotal());
        System.out.printf("%-28s Rp%,12.0f%n", "Diskon:", hitungDiskon());
        System.out.printf("%-28s Rp%,12.0f%n", "TOTAL:", hitungTotal());
        System.out.println("Metode pembayaran : " + pembayaran.getMetode());
        System.out.printf("%-28s Rp%,12.0f%n", "Uang dibayar:", uangDibayar);
        System.out.printf("%-28s Rp%,12.0f%n", "Kembalian:", kembalian);
        System.out.println("===================================================");
        System.out.println("Terima kasih sudah berkunjung!");
    }
}
