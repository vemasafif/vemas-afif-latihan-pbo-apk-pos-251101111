package poswarungkopi;

public class PembayaranTunai extends Pembayaran {
    @Override
    public double prosesPembayaran(double total, double uangDibayar) {
        if (uangDibayar < total) {
            throw new IllegalArgumentException("Uang pembayaran kurang.");
        }
        return uangDibayar - total;
    }

    @Override
    public String getMetode() {
        return "Tunai";
    }
}
