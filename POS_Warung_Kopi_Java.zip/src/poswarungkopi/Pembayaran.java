package poswarungkopi;

public abstract class Pembayaran {
    public abstract double prosesPembayaran(double total, double uangDibayar);

    public abstract String getMetode();
}
