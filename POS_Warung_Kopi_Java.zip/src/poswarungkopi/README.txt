POS KASIR WARUNG KOPI - JAVA CLI

Struktur package:
src/
  poswarungkopi/
    Main.java
    Pengguna.java
    Kasir.java
    Menu.java
    ItemPesanan.java
    Transaksi.java
    Pembayaran.java
    PembayaranTunai.java

Cara menjalankan di NetBeans:
1. Buat project Java Application bernama POSWarungKopi.
2. Buat package bernama poswarungkopi.
3. Salin semua file .java ke package tersebut (atau buka project ini jika sudah dibuat sebagai project NetBeans).
4. Jalankan Main.java.

Aturan diskon:
- Diskon 10% jika subtotal minimal Rp100.000.
- Pembayaran hanya tunai.
- Masukkan kode menu 0 untuk menyelesaikan pemesanan.

Konsep PBO:
- Class & Object: Menu, Kasir, ItemPesanan, Transaksi.
- Encapsulation: atribut private dan getter.
- Inheritance: Kasir extends Pengguna.
- Polymorphism: Kasir meng-override tampilkanInfo(); PembayaranTunai meng-override method abstract.
- Abstraction: Pembayaran adalah abstract class.

Catatan:
Ini adalah contoh proyek tugas CLI sederhana. Data transaksi disimpan di memori dan akan hilang saat program ditutup.
