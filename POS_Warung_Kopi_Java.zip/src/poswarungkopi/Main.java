package poswarungkopi;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner input = new Scanner(System.in);
    private static final List<Menu> daftarMenu = new ArrayList<>();
    private static int nomorTransaksi = 1;

    public static void main(String[] args) {
        isiDaftarMenu();

        System.out.println("========================================");
        System.out.println("       POS KASIR WARUNG KOPI");
        System.out.println("========================================");
        System.out.print("Masukkan nama kasir: ");
        String namaKasir = input.nextLine().trim();
        if (namaKasir.isEmpty()) namaKasir = "Kasir";

        Kasir kasir = new Kasir(namaKasir, "KSR001");
        kasir.tampilkanInfo();

        boolean lanjut = true;
        while (lanjut) {
            jalankanTransaksi(kasir);
            System.out.print("\nBuat transaksi baru? (y/n): ");
            lanjut = input.nextLine().trim().equalsIgnoreCase("y");
        }
        System.out.println("Program POS selesai. Sampai jumpa!");
        input.close();
    }

    private static void isiDaftarMenu() {
        daftarMenu.add(new Menu("M01", "Espresso", 15000, "Kopi"));
        daftarMenu.add(new Menu("M02", "Americano", 18000, "Kopi"));
        daftarMenu.add(new Menu("M03", "Cafe Latte", 23000, "Kopi"));
        daftarMenu.add(new Menu("M04", "Cappuccino", 22000, "Kopi"));
        daftarMenu.add(new Menu("M05", "Kopi Susu Gula Aren", 20000, "Kopi"));
        daftarMenu.add(new Menu("M06", "Teh Manis", 8000, "Non-Kopi"));
        daftarMenu.add(new Menu("M07", "Roti Bakar", 15000, "Makanan"));
        daftarMenu.add(new Menu("M08", "Kentang Goreng", 18000, "Makanan"));
    }

    private static void jalankanTransaksi(Kasir kasir) {
        String nomor = String.format("TRX%04d", nomorTransaksi++);
        Transaksi transaksi = new Transaksi(nomor, kasir);

        while (true) {
            tampilkanMenu();
            System.out.print("Masukkan kode menu (0 untuk selesai): ");
            String kode = input.nextLine().trim();

            if (kode.equals("0")) break;

            Menu menuDipilih = cariMenu(kode);
            if (menuDipilih == null) {
                System.out.println("Kode menu tidak ditemukan. Coba lagi.");
                continue;
            }

            int jumlah = bacaIntegerPositif("Jumlah pesanan: ");
            transaksi.tambahItem(menuDipilih, jumlah);
            System.out.println(jumlah + " x " + menuDipilih.getNama() + " berhasil ditambahkan.");
            System.out.printf("Subtotal sementara: Rp%,.0f%n", transaksi.hitungSubtotal());
        }

        if (transaksi.hitungSubtotal() == 0) {
            System.out.println("Transaksi dibatalkan karena belum ada pesanan.");
            return;
        }

        System.out.printf("\nSubtotal : Rp%,.0f%n", transaksi.hitungSubtotal());
        System.out.printf("Diskon   : Rp%,.0f%n", transaksi.hitungDiskon());
        System.out.printf("TOTAL    : Rp%,.0f%n", transaksi.hitungTotal());

        Pembayaran pembayaran = new PembayaranTunai();
        double uangDibayar;
        while (true) {
            uangDibayar = bacaNominal("Uang dibayar (Rp): ");
            if (uangDibayar >= transaksi.hitungTotal()) break;
            System.out.println("Uang kurang. Silakan masukkan nominal yang cukup.");
        }

        double kembalian = pembayaran.prosesPembayaran(transaksi.hitungTotal(), uangDibayar);
        transaksi.cetakStruk(pembayaran, uangDibayar, kembalian);
    }

    private static void tampilkanMenu() {
        System.out.println("\n---------------- DAFTAR MENU ----------------");
        System.out.printf("%-5s %-22s %-12s %s%n", "Kode", "Nama", "Kategori", "Harga");
        for (Menu menu : daftarMenu) menu.tampilkanMenu();
        System.out.println("---------------------------------------------");
    }

    private static Menu cariMenu(String kode) {
        for (Menu menu : daftarMenu) {
            if (menu.getKode().equalsIgnoreCase(kode)) return menu;
        }
        return null;
    }

    private static int bacaIntegerPositif(String pesan) {
        while (true) {
            System.out.print(pesan);
            try {
                int nilai = Integer.parseInt(input.nextLine().trim());
                if (nilai > 0) return nilai;
                System.out.println("Masukkan angka lebih dari 0.");
            } catch (NumberFormatException e) {
                System.out.println("Input harus berupa bilangan bulat.");
            }
        }
    }

    private static double bacaNominal(String pesan) {
        while (true) {
            System.out.print(pesan);
            try {
                double nilai = Double.parseDouble(input.nextLine().trim());
                if (nilai >= 0) return nilai;
                System.out.println("Nominal tidak boleh negatif.");
            } catch (NumberFormatException e) {
                System.out.println("Masukkan nominal berupa angka tanpa titik pemisah ribuan.");
            }
        }
    }
}
