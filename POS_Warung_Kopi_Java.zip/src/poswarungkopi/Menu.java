package poswarungkopi;

public class Menu {
    private String kode;
    private String nama;
    private double harga;
    private String kategori;

    public Menu(String kode, String nama, double harga, String kategori) {
        this.kode = kode;
        this.nama = nama;
        this.harga = harga;
        this.kategori = kategori;
    }

    public String getKode() { return kode; }
    public String getNama() { return nama; }
    public double getHarga() { return harga; }
    public String getKategori() { return kategori; }

    public void tampilkanMenu() {
        System.out.printf("%-5s %-22s %-12s Rp%,.0f%n",
                kode, nama, kategori, harga);
    }
}
